//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VisVim.rc
//
#define IDS_VISVIM_LONGNAME		1
#define IDS_VISVIM_DESCRIPTION		2
#define IDS_CMD_DIALOG			3
#define IDS_CMD_ENABLE			4
#define IDS_CMD_DISABLE			5
#define IDS_CMD_TOGGLE			6
#define IDS_CMD_LOAD			7
#define IDR_TOOLBAR_MEDIUM		128
#define IDR_TOOLBAR_LARGE		129
#define IDD_ADDINMAIN			130
#define IDC_DEVSTUDIO_EDITOR		1000
#define IDC_CD_SOURCE_PATH		1001
#define IDC_CD_SOURCE_PARENT		1002
#define IDC_CD_NONE			1003
#define IDC_NEW_TABS			1004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	131
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1004
#define _APS_NEXT_SYMED_VALUE		101
#endif
#endif
